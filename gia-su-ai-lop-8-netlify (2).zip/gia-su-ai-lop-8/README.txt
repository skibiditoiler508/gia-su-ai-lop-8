GIA SU AI LOP 8 - NETLIFY

1. Upload thu muc nay len GitHub repository hoac import repository vao Netlify.
2. Trong Netlify: Site configuration > Environment variables.
3. Them GEMINI_API_KEY = API key Gemini cua ban.
4. Deploy lai website.

Khong dat API key vao index.html va khong commit API key len GitHub.
Can nguoi lon/ giao vien ho tro tao API key va kiem soat han muc su dung.
