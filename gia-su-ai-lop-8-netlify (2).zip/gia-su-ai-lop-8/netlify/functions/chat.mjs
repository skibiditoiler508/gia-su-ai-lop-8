export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    const { contents, systemInstruction } = await req.json();
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "Máy chủ chưa được cấu hình GEMINI_API_KEY." }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }

    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    const upstream = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents, systemInstruction: { parts: [{ text: systemInstruction }] } }),
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      return new Response(JSON.stringify({ error: "Dịch vụ AI đang gặp lỗi. Vui lòng thử lại." }), {
        status: upstream.status,
        headers: { "Content-Type": "application/json" },
      });
    }

    const reply = result?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!reply) throw new Error("Empty response from AI provider");
    return new Response(JSON.stringify({ reply }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: "Không xử lý được yêu cầu. Vui lòng thử lại." }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
};
