const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

export default async (request) => {
  if (request.method === "OPTIONS") return new Response("", { status: 204, headers });
  if (request.method !== "POST") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });

  const apiKey = process.env.GEMINI_API_KEY;
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  if (!apiKey) return new Response(JSON.stringify({ error: "Chủ website chưa cấu hình GEMINI_API_KEY trên Netlify." }), { status: 500, headers });

  try {
    const body = await request.json();
    if (!Array.isArray(body.contents) || body.contents.length === 0) {
      return new Response(JSON.stringify({ error: "Vui lòng nhập câu hỏi." }), { status: 400, headers });
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const upstream = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: body.contents,
        systemInstruction: body.systemInstruction ? { parts: [{ text: String(body.systemInstruction).slice(0, 5000) }] } : undefined,
        generationConfig: { maxOutputTokens: 1200, temperature: 0.6 }
      })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      const message = result?.error?.message || "Gemini API không phản hồi thành công.";
      return new Response(JSON.stringify({ error: message }), { status: upstream.status, headers });
    }
    const reply = result?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
    if (!reply) return new Response(JSON.stringify({ error: "AI trả về nội dung trống. Hãy thử hỏi lại." }), { status: 502, headers });
    return new Response(JSON.stringify({ reply }), { status: 200, headers });
  } catch (error) {
    return new Response(JSON.stringify({ error: "Không xử lý được yêu cầu. Vui lòng thử lại." }), { status: 500, headers });
  }
};