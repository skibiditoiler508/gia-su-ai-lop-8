# Gia sư AI Lớp 8

## Chạy và xuất bản công khai bằng Netlify

1. Tạo tài khoản tại https://www.netlify.com/ và đăng nhập.
2. Đưa toàn bộ thư mục này lên một GitHub repository (hoặc tải ZIP lên Netlify nếu giao diện tài khoản có hỗ trợ).
3. Trong Netlify chọn **Add new site → Import an existing project**, kết nối repository.
4. Trong **Site configuration → Environment variables**, thêm:
   - `GEMINI_API_KEY` = API key Gemini của chủ website
   - `GEMINI_MODEL` = `gemini-2.5-flash` (có thể đổi theo model được bật trong tài khoản Google AI Studio)
5. Deploy site. Netlify sẽ cấp một URL dạng `https://ten-site.netlify.app`.
6. Gửi URL đó cho mọi người. Chọn quyền truy cập công khai; không bật bảo vệ mật khẩu.

## Lưu ý quan trọng
- API key chỉ lưu ở biến môi trường phía máy chủ, không đặt trong HTML và không chia sẻ công khai.
- Mọi người có thể mở website, nhưng lượt gọi AI sử dụng hạn mức/quota và có thể phát sinh chi phí theo chính sách của Google. Chủ website cần theo dõi mức sử dụng, đặt giới hạn/billing phù hợp và không đăng API key lên mạng.
- Bản này không lưu hội thoại trên máy chủ; làm mới trang sẽ bắt đầu phiên mới.
- Nếu muốn website dùng lâu dài cho nhiều người, nên bổ sung giới hạn tần suất (rate limit), chống lạm dụng và theo dõi chi phí.
